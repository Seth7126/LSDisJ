-- TODO
describe("cli")
